package fastcampus.aop.part2.chapter03

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.util.Log
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import androidx.core.widget.addTextChangedListener

class DiaryActivity: AppCompatActivity() {

    //핸들러 생성
    private val handler = Handler(Looper.getMainLooper())//메인루퍼 ->메인스레드연결

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diary)

        val diaryEditText = findViewById<EditText>(R.id.diaryEditText)
        val detailPreferences = getSharedPreferences("diary", Context.MODE_PRIVATE)

        diaryEditText.setText(detailPreferences.getString("detail",""))

        //중간중간 멈췄을때 스레드 사용하여 저장
        val runnable = Runnable {//러너블 이터페이스 구현
            getSharedPreferences("diary", Context.MODE_PRIVATE).edit{
                putString("detail", diaryEditText.text.toString())//비동기로 수시로저장
            }
            Log.d("DiaryActivity","SAVE :: ${diaryEditText.text.toString()}")
        }

        //글 내용 변경시 저장
        diaryEditText.addTextChangedListener {

            Log.d("DiaryActivity","TextChanged :: $it")
           //핸들러 사용 메인 스레드와 연결
            //몇초지연후 러너블 되는 스레드실행
            handler.removeCallbacks(runnable)//러너블실행전에 쓴내용은 삭제됨
            handler.postDelayed(runnable,500)

            }
        }
    }
