package fastcampus.aop.part2.chapter5_final

import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import kotlin.concurrent.timer

class PhotoFrameActivity: AppCompatActivity() {


    private val photoList = mutableListOf<Uri>()

    private var currentPosition = 0

    private var timer: Timer? = null

    private val photoImageView: ImageView by lazy {
        findViewById<ImageView>(R.id.photoImageView)
    }

    private val backgroundImageView: ImageView by lazy {
        findViewById<ImageView>(R.id.backgroundPhotoImageView)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_photoframe)

        Log.d("PhotoFame", "onCreate! timer cancel")
        getPhothoUriFromIntent()

        startTimer()
    }

    private fun getPhothoUriFromIntent(){

        val size = intent.getIntExtra("photoListSize", 0)
        for (i in 0..size) { //0부터 사이즈 까지
            //인덴트의 게스트링엑스트라의 포토의 인덱스를 가져오는데 널일수있으므로
            //렛 합수로 널이 아닐때만 실행하도록 한다
            intent.getStringExtra("photo$i")?.let {
                photoList.add(Uri.parse(it))
            }
        }
    }

    //5초에 한번씩 화면 전환. 타이머 사용
    private fun startTimer() {
        timer = timer(period = 5 * 1000){
            //타이머 5초에 한번씩 어떤게 실행될 것인지 설정
            runOnUiThread{//메인스레드로 변환해줘야 한다

                Log.d("PhotoFame", "5초가 지나감")
                val current = currentPosition //로컬변수로 저장
                //마지막 이미지에서 첫번째 이미지로 돌아오는 로직
                //포토리스트의 사이즈가 커런트 포지션의 +1보다 작거나 같을때는 0
                val next = if (photoList.size <= currentPosition + 1 ) 0 else currentPosition + 1

                backgroundImageView.setImageURI(photoList[current])
                //백그라운드에 셋이미지 유알아이를 해준다
                //
                photoImageView.alpha = 0f// 투명도를 0으로 준다
                photoImageView.setImageURI(photoList[next])// 다음 이미지뷰가 보여지지 않는다
                photoImageView.animate()
                    .alpha(1.0f)
                    .setDuration(1000)
                    .start()
                currentPosition = next
            }
        }
    }

    override fun onStop() {
        super.onStop()

        Log.d("PhotoFame", "onStop! timer cancel")

        timer?.cancel()
    }

    override fun onStart() {
        super.onStart()

        Log.d("PhotoFame", "onStart! timer cancel")

        startTimer()
    }

    override fun onDestroy() {
        super.onDestroy()

        Log.d("PhotoFame", "onDestroy! timer cancel")

        timer?.cancel()
    }

}
