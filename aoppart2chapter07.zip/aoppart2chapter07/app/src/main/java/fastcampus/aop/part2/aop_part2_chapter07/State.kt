package fastcampus.aop.part2.aop_part2_chapter07

enum class State {

    BEFORE_RECORDING,
    ON_RECORDING,
    AFTER_RECORDING,
    ON_PLAYING

}