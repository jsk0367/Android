package fastcampus.aop.part2.aop_part2_chapter08

import android.annotation.SuppressLint
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.webkit.URLUtil
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import androidx.core.widget.ContentLoadingProgressBar
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private val goHomeButton: ImageButton by lazy {
        findViewById(R.id.goHomeButton)
    }

    private val addressBar: EditText by lazy {

        findViewById(R.id.addressBar)
    }

    private val goBackButton: ImageButton by lazy {
        findViewById(R.id.goBackButton)
    }

    private val goFowardButton: ImageButton by lazy {
        findViewById(R.id.goForwardButton)
    }

    private val webView: WebView by lazy {
        findViewById(R.id.webView)
    }

    private val refreshLayout: SwipeRefreshLayout by lazy {
        findViewById(R.id.refreshLayout)
    }

    private val progressBar: ContentLoadingProgressBar by lazy {
        findViewById(R.id.progressBar)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        bindViews()
    }

    override fun onBackPressed() { //백 버튼을 눌렀을때 호출 되는 메서드
        if(webView.canGoBack()){
            webView.goBack() // 뒤로 갈수 있다면 goback을 한다
        }else {
            super.onBackPressed()// 그게 아니라면 기본과 동일하게
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initViews(){
        webView.apply {
            webViewClient = WebViewClient()// 코드를 입력하지 않으면 우리가 만든 웹뷰가 안뜨고 바로 구글 사이트로 이동해버린다
            webChromeClient = WebChromClient()
            settings.javaScriptEnabled = true //사이트로드시 자바스크립트를 사용할수있게 해줌
            loadUrl(DEFAULT_URL)
        }
    }

    private fun bindViews() {
        goHomeButton.setOnClickListener {
            webView.loadUrl(DEFAULT_URL)
        }
        
        addressBar.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { //주소창에 주소 입력하고 던 버튼 눌렀을때
                val loadingUrl = v.text.toString()
                if(URLUtil.isNetworkUrl(loadingUrl)){
                    webView.loadUrl(loadingUrl)
                } else {
                    webView.loadUrl("http://$loadingUrl")
                }
               // webView.loadUrl(v.text.toString())//지금 클릭한 주소창에 텍스를 가져와서 스트링으로 변환 후 전달
            }
            return@setOnEditorActionListener false //키보를 내려야 하기 때문에 폴스
        }

        goBackButton.setOnClickListener {
            webView.goBack()//webview 에 고백을 호출하면 전화면으로 이동된ㄷ
        }

        goFowardButton.setOnClickListener{
            webView.goForward()
        }

        refreshLayout.setOnRefreshListener {
            webView.reload()
        }
        
    }

    inner class WebViewClient: android.webkit.WebViewClient(){ //inner를 붙여줌으로써 상위에 있는 클래스에 접근할수있다

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)

            progressBar.show()// 홈페이지가 시작될때 바가 보이고
        }

        override fun onPageFinished(view: WebView?, url: String?) { //페이지가 로딩완료했을때
            super.onPageFinished(view, url)

            refreshLayout.isRefreshing = false //로딩이 완료되면 리프레쉬 아이콘이 사라진다
            progressBar.hide() // 로딩이 완료되면 사라진다
            goBackButton.isEnabled = webView.canGoBack()// 뒤로 갈수있는 히스토리가 트루면 뒤고 가게한다 아니면 희믜하게 처리하여 더이상 뒤로갈수없게 만든다
            goFowardButton.isEnabled = webView.canGoForward()//갈수 있을 경우에만 활성화됨
            addressBar.setText(url)//최종적으로 로딩된 주소가 전달된다
        }
    }

    inner class WebChromClient: android.webkit.WebChromeClient(){

        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            super.onProgressChanged(view, newProgress)

            progressBar.progress = newProgress
        }
    }
    
    companion object {
        private const val DEFAULT_URL = "http://www.google.com"
    }
}